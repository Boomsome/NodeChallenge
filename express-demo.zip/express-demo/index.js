// loads the express module
const { request, response } = require('express');
const express = require('express');
// creates an instance of express inside app (our application)
const app = express();
app.use(express.json());


const http = require('https');
const LineByLineReader = require('line-by-line');
const { string, object } = require('joi');

const options = {
  host: 'adstxt.pubgenius.io',
  path: '/bjpenn.com/ads.txt',
  method: 'GET',
};

let fileData = [];
let publisherData = []; // same index data
let objectArray = [];
let publishName = []; // same index name
let lineCount = 0; 
let nameNumber = -1;
let currentName = false;

const req = http.request(options, (res) => {
  res.setEncoding('utf8');

  lr = new LineByLineReader(res);


  lr.on('error', function (err) {
    console.log('err', err);
  });

  lr.on('line', function (line) {
    
    if (line[0] === '#' && lineCount > 8) {
        publishName.push(line.substring(1, line.length)); 
        currentName = true;
        nameNumber++;
        let arry = [];
        publisherData.push(arry);
    } else if (currentName) {
        if (line === "") {
            currentName = false;
        } else {
            let adName = line.split(',')[0];
            if (!publisherData[nameNumber].includes(adName)) {
                 publisherData[nameNumber].push(adName);
            }
        }
    }

    fileData.push(line);
    lineCount++;
  }
  );

  lr.on('end', function () {
    console.log('end');
  });

});
req.on('error', (e) => {
  console.log('problem with request', e);
  req.destroy();
});
req.end();

app.get('/', (request, response) => {
    response.send('Base Website');
});



app.get('/publishers', (request, response) => {
    for (let i = 0; i < publishName.length; i++) {
        response.write(publishName[i] + ": " + "\n[" + publisherData[i] +"]\n");
        //response.send(publisherData[i]);
    }
});

// get a single course
app.get('/publishers/:publisher_id', (request,response) => {
    
    for (let i = 0; i < publishName.length; i++) {
        let obj = {publisher_id: publishName[i], publisher_data: publisherData[i]};
        objectArray.push(obj);
    }

    const publisher = objectArray.find(c => c.publisher_id === request.params.publisher_id);
    if (!publisher) {
        response.status(404).send('The publisher with the given ID was not found');
    }
    response.send(publisher.publisher_data);
});


// PORT - environment variable
const port = process.env.PORT || 3000;
app.listen(port, () => console.log(`Listening on port ${port}...`));
